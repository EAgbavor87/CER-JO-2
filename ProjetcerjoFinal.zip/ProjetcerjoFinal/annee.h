#ifndef ANNEE_H
#define ANNEE_H

/// FONCTION POUR DETERMINER L'ACTUELLE ///

int annee_actuelle();

#endif