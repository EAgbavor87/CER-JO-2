#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "coureur.h"
#include "epreuve.h"
#include "scan.h"
#include "annee.h"
#include "fichier.h"
#include "statistiques.h"
#include "100m.h"

#define MAX_TAILLE 300
#define MAX_CHAR 50

void ajouter_100m(COUREUR *coureur, EPREUVE *epreuve) {
  FILE *fichier = coureur->fichier;
  int i = 0, j = 0;
  float temps;

  printf("\n------------------ ÉPREUVE DU 100m "
         "----------------------\n\nSaisir la date\n\n");

  do {
    epreuve->jour = scan_Int("Jour : "); 

    if (epreuve->jour < 1 || epreuve->jour > 30) {
      printf("\nERREUR : Le jour doit être compris entre 1 et 30 inclus.\n");
    }
  } while (epreuve->jour < 1 || epreuve->jour > 30);

  do {
    epreuve->mois = scan_Int("Mois : ");

    if (epreuve->mois < 1 || epreuve->mois > 12) {
      printf("\nERREUR : Le mois doit être compris entre 1 et 12 inclus.\n");
    }
  } while (epreuve->mois < 1 || epreuve->mois > 12);

  do {
    epreuve->annee = scan_Int("Année : ");

    if (epreuve->annee != annee_actuelle()) {
      printf("\nERREUR : L'année doit correspondre à celle actuelle.\n");
    }
  } while (epreuve->annee != annee_actuelle());

  do {
    printf("\nOù le coureur a réalisé l'entrainement ? : ");
    fgets(epreuve->lieu, MAX_CHAR, stdin);
    // Supprimer le caractère de nouvelle ligne '\n' ajouté par fgets
    epreuve->lieu[strcspn(epreuve->lieu, "\n")] = '\0';

    if (strlen(epreuve->lieu) < 2 || strlen(epreuve->lieu) > MAX_CHAR) {
      printf("\nERREUR : Le lieu doit contenir au moins 2 lettres et %d au maximum.\n", MAX_CHAR);
    }
  } while (strlen(epreuve->lieu) < 2 || strlen(epreuve->lieu) > MAX_CHAR || !char_valide(epreuve->lieu));

  do {
    temps = scan_Float("\nQuel est le temps réalisé ? (en secondes) : ");

    if (temps < 0) {
      printf("\nERREUR : Le temps doit être strictement positif.\n");
    }
  } while (temps < 0);

  while (i < MAX_TAILLE && coureur->temps_100m[i] != 0.0) {
    i++;
  }

  while (j < MAX_TAILLE) {
    if (coureur->nom == epreuve->tab_coureurs[j]->nom && coureur->prenom == epreuve->tab_coureurs[j]->prenom && coureur->age == epreuve->tab_coureurs[j]->age) {
      break;
    } else if (epreuve->tab_coureurs[j] == NULL) {
      epreuve->tab_coureurs[j] = coureur;
      break;
    }
    j++;
  }
  
  coureur->temps_100m[i] = temps;
  strcpy(epreuve->nom, "100m");

  // Construire le nom du fichier en utilisant le contenu de la variable
  sprintf(coureur->nom, "%s.txt", coureur->nom);

  // Vérifier si le fichier existe
  fichier = fopen(coureur->nom, "r");
  if (fichier == NULL) {
    fichier = fopen(coureur->nom, "w");
  }
  else {
    fichier = fopen(coureur->nom, "a");
  }
  
  if (fichier == NULL) {
    fprintf(stderr, "\nErreur lors de l'ouverture du fichier.\n");
    exit(EXIT_FAILURE);
  }

  fprintf(fichier, "\n------------------ ÉPREUVE DU 100m ----------------------\n\n");

  fprintf(fichier, "Date de l'épreuve : %02d/%02d/%d\n", epreuve->jour, epreuve->mois, epreuve->annee);
  fprintf(fichier, "Lieu de l'épreuve : %s\n", epreuve->lieu);
  fprintf(fichier, "Temps réalisé : %.2f secondes\n", temps);

  fclose(fichier);

  char *point = strrchr(coureur->nom, '.');

  if (point != NULL) {
      *point = '\0';
  }
}

void afficher_100m(COUREUR *coureur) {
  int i = 0;
  float resultat;

  printf("\n\nToutes les performances du 100m : \n\n");

  for (int i = 0; i < MAX_TAILLE; i++) {
    if (coureur->temps_100m[i] == 0.0) {
      break;
    }
    printf("[%.2f]\t", coureur->temps_100m[i]);
  }
  
  float temps_min = min(coureur->temps_100m);
  coureur->min_100m = temps_min;
  printf("\n\nMeilleure performance du 100m : %.2f secondes\n", coureur->min_100m);

  float temps_max = max(coureur->temps_100m);
  coureur->max_100m = temps_max;
  printf("\nPire performance du 100m : %.2f secondes\n", coureur->max_100m);

  float temps_moyen = moyenne(coureur->temps_100m);
  coureur->moyenne_100m = temps_moyen;
  printf("\nMoyenne des performances du 100m : %.2f secondes\n", coureur->moyenne_100m);

  while (i < MAX_TAILLE && coureur->temps_100m[i] != 0.0) {
    if (i > 0){
      resultat = coureur->temps_100m[i-1] - coureur->temps_100m[i];

      if (resultat > 0) {
        printf("\nAmélioration de %.2f secondes entre la %de et la %de performance du 100m.\n", resultat, i, i+1);
      } else if (resultat < 0) {
        printf("\nBaisse de %.2f secondes entre la %de et la %de performance du 100m.\n", -resultat, i, i+1);
      }
      else {
        printf("\nTemps constant entre la %de et la %de performance du 100m.\n", i, i+1);
      }
    }
    i++;
  }

}

/// FONCTION DE TRI (PAR SÉLECTION) ///

void tri_100m(EPREUVE *epreuve) {
    for (int i = 0; i < MAX_TAILLE - 1; i++) {
        if (epreuve->tab_coureurs[i] == NULL) {
            break; // Sortir de la boucle si nous avons atteint la fin des coureurs valides
        }
        int min_idx = i;
        
        // Trouver l'élément minimum dans le tableau non trié
        for (int j = i + 1; j < MAX_TAILLE; j++) {
            if (epreuve->tab_coureurs[j] == NULL) {
                break; // Sortir de la boucle si nous avons atteint la fin des coureurs valides
            }
            if (epreuve->tab_coureurs[j]->moyenne_100m < epreuve->tab_coureurs[min_idx]->moyenne_100m) {
                min_idx = j;
            }
        }
        
        // Échanger l'élément minimum avec le premier élément
        COUREUR *temp = epreuve->tab_coureurs[min_idx];
        epreuve->tab_coureurs[min_idx] = epreuve->tab_coureurs[i];
        epreuve->tab_coureurs[i] = temp;
    }
}

void moyenne_100m(EPREUVE *epreuve) {
    int i = 0;

    while (i < MAX_TAILLE && epreuve->tab_coureurs[i] != NULL) {
        float temps_moyen = 0.0;
        int j = 0;
        int nb_temps = 0;

        // Parcourir tous les temps de 100m pour le coureur actuel
        while (j < MAX_TAILLE && epreuve->tab_coureurs[i]->temps_100m[j] != 0.0) {
            temps_moyen += epreuve->tab_coureurs[i]->temps_100m[j];
            j++;
            nb_temps++;
        }

        // Calculer la moyenne seulement si nb_temps est supérieur à 0 pour éviter la division par zéro
        if (nb_temps > 0) {
            epreuve->tab_coureurs[i]->moyenne_100m = temps_moyen / nb_temps;
        } else {
            epreuve->tab_coureurs[i]->moyenne_100m = 0.0; // Aucun temps enregistré
        }
        i++;
    }
}