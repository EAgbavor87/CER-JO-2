#ifndef RELAIS_H
#define RELAIS_H

#include "coureur.h"
#include "epreuve.h"

void ajouter_relais(COUREUR *coureur_1, COUREUR *coureur_2, COUREUR *coureur_3, COUREUR *coureur_4, EPREUVE *epreuve);
void afficher_relais(COUREUR *coureur);
void tri_relais(EPREUVE *epreuve);
void moyenne_relais(EPREUVE *epreuve);

#endif