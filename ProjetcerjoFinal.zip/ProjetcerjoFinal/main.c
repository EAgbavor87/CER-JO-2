#include <string.h>
#include "coureur.h"
#include "epreuve.h"
#include "menu.h"

int main() {
  COUREUR *coureur = NULL;
  EPREUVE *epreuve = NULL;

  coureur = malloc(sizeof(COUREUR));
  if (coureur == NULL) {
    printf("\nErreur d'allocation de mémoire.\n");
    exit(EXIT_FAILURE);
  }

  epreuve = malloc(sizeof(EPREUVE));
  if (epreuve == NULL) {
    printf("\nErreur d'allocation de mémoire.\n");
    exit(EXIT_FAILURE);
  }

  for (int i = 0; i < MAX_TAILLE; i++) {
    epreuve->tab_coureurs[i] = NULL;
    epreuve->dates_relais[i] = 0;
  }

  strcpy(coureur->nom, "");

  menu(coureur, epreuve);
  return 0;
}