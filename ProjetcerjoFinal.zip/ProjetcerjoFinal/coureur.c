#include <stdio.h>
#include <stdlib.h> // Pour malloc
#include <string.h> // Pour strlen et fgets
#include "coureur.h"
#include "fichier.h"

// Définition de la fonction constructeur_coureur
COUREUR *constructeur_coureur() {
  COUREUR *coureur = malloc(sizeof(COUREUR));
  coureur->fichier = NULL;

  if (coureur == NULL) {
    printf("\nErreur d'allocation de mémoire.\n");
    exit(EXIT_FAILURE);
  }

  for (int i = 0; i < MAX_TAILLE; i++) {
    coureur->temps_100m[i] = 0.0;
    coureur->temps_400m[i][0] = 0;
    coureur->temps_5000m[i][0] = 0;
    coureur->temps_relais_equipe[i][0] = 0;
    coureur->temps_marathon[i][0] = 0;
  }

  do {
    printf("\nQuel est le nom du coureur ? : ");
    fgets(coureur->nom, MAX_CHAR, stdin);
    coureur->nom[strcspn(coureur->nom, "\n")] = '\0';

    if (strlen(coureur->nom) < 2 || strlen(coureur->nom) > MAX_CHAR) {
      printf("\nERREUR : Le nom doit contenir au moins 2 lettres et %d au maximum.\n", MAX_CHAR);
    }
  } while (strlen(coureur->nom) < 2 || strlen(coureur->nom) > MAX_CHAR || !char_valide(coureur->nom));

  do {
    printf("Quel est le prénom du coureur ? : ");
    fgets(coureur->prenom, MAX_CHAR, stdin);
    coureur->prenom[strcspn(coureur->prenom, "\n")] = '\0';

    if (strlen(coureur->prenom) < 2 || strlen(coureur->prenom) > MAX_CHAR) {
      printf("\nERREUR : Le prénom doit contenir au moins 2 lettres et %d au maximum.\n", MAX_CHAR);
    }
  } while (strlen(coureur->nom) < 2 || strlen(coureur->nom) > MAX_CHAR || !char_valide(coureur->prenom));

  do {
    coureur->age = scan_Int("Quel est l'âge du coureur ? : ");

    if (coureur->age < 16 || coureur->age > 50) {
      printf("\nERREUR : L'âge requis est compris entre 16 et 50 ans inclus.\n");
    }
  } while (coureur->age < 16 || coureur->age > 50);

  printf("\nLe coureur %s %s a été ajouté à vos sportifs.\n", coureur->prenom,
         coureur->nom);

  liste_coureur(coureur);

  return coureur;
}
