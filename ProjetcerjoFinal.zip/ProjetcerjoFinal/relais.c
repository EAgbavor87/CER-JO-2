#include <string.h>
#include "coureur.h"
#include "epreuve.h"
#include "annee.h"
#include "statistiques.h"
#include "relais.h"

void ajouter_relais(COUREUR *coureur_1, COUREUR *coureur_2, COUREUR *coureur_3, COUREUR *coureur_4, EPREUVE *epreuve) {
  FILE *fichier_1, *fichier_2, *fichier_3, *fichier_4;
  int minutes, secondes, temps_total;
  int i = 0, j = 0, k = 0, l = 0, m = 0, n = 0, o = 0, p = 0, a = 1;

  fichier_1 = coureur_1->fichier;
  fichier_2 = coureur_2->fichier;
  fichier_3 = coureur_3->fichier;
  fichier_4 = coureur_4->fichier;

  printf("\n------------------ ÉPREUVE DU RELAIS "
         "----------------------\n\nSaisir la date\n\n");

  do {
    epreuve->jour = scan_Int("Jour : "); 

    if (epreuve->jour < 1 || epreuve->jour > 30) {
      printf("\nERREUR : Le jour doit être compris entre 1 et 30 inclus.\n");
    }
  } while (epreuve->jour < 1 || epreuve->jour > 30);

  do {
    epreuve->mois = scan_Int("Mois : ");

    if (epreuve->mois < 1 || epreuve->mois > 12) {
      printf("\nERREUR : Le mois doit être compris entre 1 et 12 inclus.\n");
    }
  } while (epreuve->mois < 1 || epreuve->mois > 12);

  do {
    epreuve->annee = scan_Int("Année : ");

    if (epreuve->annee != annee_actuelle()) {
      printf("\nERREUR : L'année doit correspondre à celle actuelle.\n");
    }
  } while (epreuve->annee != annee_actuelle());

  for (int i = 1; i < (MAX_TAILLE - 4); i=3*i) {
    if (epreuve->dates_relais[i] == 0) {
      break;
    } else if (epreuve->jour == epreuve->dates_relais[i] && epreuve->mois == epreuve->dates_relais[i+1] && epreuve->annee == epreuve->dates_relais[i+2]) {
      printf("\nERREUR : Il ne peut uniquement y avoir qu'une épreuve de relais par jour.\n");
      return;
    }
  }

  while (a < (MAX_TAILLE - 4) && epreuve->dates_relais[a] != 0) {
    a++;
  }
  
  epreuve->dates_relais[a] = epreuve->jour;
  epreuve->dates_relais[a+1] = epreuve->mois;
  epreuve->dates_relais[a+2] = epreuve->annee;

  do {
    printf("\nOù les coureurs ont réalisé leur entrainement ? : ");
    fgets(epreuve->lieu, MAX_CHAR, stdin);
    // Supprimer le caractère de nouvelle ligne '\n' ajouté par fgets
    epreuve->lieu[strcspn(epreuve->lieu, "\n")] = '\0';

    if (strlen(epreuve->lieu) < 2 || strlen(epreuve->lieu) > MAX_CHAR) {
      printf("\nERREUR : Le lieu doit contenir au moins 2 lettres et %d au maximum.\n", MAX_CHAR);
    }
  } while (strlen(epreuve->lieu) < 2 || strlen(epreuve->lieu) > MAX_CHAR || !char_valide(epreuve->lieu));

  do {
    printf("\nQuel est le temps réalisé du premier 400m par le "
                          "premier coureur ?");

    coureur_1->minutes = scan_Int("\n\nMinutes : ");
    coureur_1->secondes = scan_Int("Secondes : ");

    if (coureur_1->minutes > 59 || coureur_1->secondes > 59) {
      printf("\nERREUR : Les minutes et secondes sont comprises entre 1 et 59.\n");
    }
  } while (coureur_1->minutes > 59 || coureur_1->secondes > 59);

  do {
    printf("\nQuel est le temps réalisé du premier 400m par le "
                          "second coureur ?");

    coureur_2->minutes = scan_Int("\n\nMinutes : ");
    coureur_2->secondes = scan_Int("Secondes : ");

    if (coureur_2->minutes > 59 || coureur_2->secondes > 59) {
      printf("\nERREUR : Les minutes et secondes sont comprises entre 1 et 59.\n");
    }
  } while (coureur_2->minutes > 59 || coureur_2->secondes > 59);

  do {
    printf("\nQuel est le temps réalisé du premier 400m par le "
                          "troisième coureur ?");

    coureur_3->minutes = scan_Int("\n\nMinutes : ");
    coureur_3->secondes = scan_Int("Secondes : ");

    if (coureur_3->minutes > 59 || coureur_3->secondes > 59) {
      printf("\nERREUR : Les minutes et secondes sont comprises entre 1 et 59.\n");
    }
  } while (coureur_3->minutes > 59 || coureur_3->secondes > 59);

  do {
    printf("\nQuel est le temps réalisé du premier 400m par le "
                          "quatrième coureur ?");

    coureur_4->minutes = scan_Int("\n\nMinutes : ");
    coureur_4->secondes = scan_Int("Secondes : ");

    if (coureur_4->minutes > 59 || coureur_4->secondes > 59) {
      printf("\nERREUR : Les minutes et secondes sont comprises entre 1 et 59.\n");
    }
  } while (coureur_4->minutes > 59 || coureur_4->secondes > 59);

  while (i < MAX_TAILLE && coureur_1->temps_relais_equipe[i][0] != 0) {
    i++;
  }

  while (j < MAX_TAILLE && coureur_2->temps_relais_equipe[j][0] != 0) {
    j++;
  }

  while (k < MAX_TAILLE && coureur_3->temps_relais_equipe[k][0] != 0) {
    k++;
  }

  while (l < MAX_TAILLE && coureur_4->temps_relais_equipe[l][0] != 0) {
    l++;
  }

  while (m < MAX_TAILLE) {
    if (coureur_1->nom == epreuve->tab_coureurs[m]->nom && coureur_1->prenom == epreuve->tab_coureurs[m]->prenom && coureur_1->age == epreuve->tab_coureurs[m]->age) {
      break;
    } else if (epreuve->tab_coureurs[m] == NULL) {
      epreuve->tab_coureurs[m] = coureur_1;
      break;
    }
    m++;
  }

  while (n < MAX_TAILLE) {
    if (coureur_2->nom == epreuve->tab_coureurs[n]->nom && coureur_2->prenom == epreuve->tab_coureurs[n]->prenom && coureur_2->age == epreuve->tab_coureurs[n]->age) {
      break;
    } else if (epreuve->tab_coureurs[n] == NULL) {
      epreuve->tab_coureurs[n] = coureur_2;
      break;
    }
    n++;
  }

  while (o < MAX_TAILLE) {
    if (coureur_3->nom == epreuve->tab_coureurs[o]->nom && coureur_3->prenom == epreuve->tab_coureurs[o]->prenom && coureur_3->age == epreuve->tab_coureurs[o]->age) {
      break;
    } else if (epreuve->tab_coureurs[o] == NULL) {
      epreuve->tab_coureurs[o] = coureur_3;
      break;
    }
    o++;
  }

  while (p < MAX_TAILLE) {
    if (coureur_4->nom == epreuve->tab_coureurs[p]->nom && coureur_4->prenom == epreuve->tab_coureurs[p]->prenom && coureur_4->age == epreuve->tab_coureurs[p]->age) {
      break;
    } else if (epreuve->tab_coureurs[p] == NULL) {
      epreuve->tab_coureurs[p] = coureur_4;
      break;
    }
    p++;
  }

  coureur_1->temps_relais_personnel[i][0] = (coureur_1->minutes * 60) + coureur_1->secondes;
  coureur_2->temps_relais_personnel[j][0] = (coureur_2->minutes * 60) + coureur_2->secondes;
  coureur_3->temps_relais_personnel[k][0] = (coureur_3->minutes * 60) + coureur_3->secondes;
  coureur_4->temps_relais_personnel[l][0] = (coureur_4->minutes * 60) + coureur_4->secondes;

  temps_total = coureur_1->temps_relais_personnel[i][0] + coureur_2->temps_relais_personnel[j][0] + coureur_3->temps_relais_personnel[k][0] + coureur_4->temps_relais_personnel[l][0];
  minutes = temps_total / 60;
  secondes = temps_total % 60;
  
  coureur_1->temps_relais_equipe[i][0] = temps_total;
  coureur_2->temps_relais_equipe[j][0] = temps_total;
  coureur_3->temps_relais_equipe[k][0] = temps_total;
  coureur_4->temps_relais_equipe[l][0] = temps_total;

  strcpy(epreuve->nom, "Relais");

  sprintf(coureur_1->nom, "%s.txt", coureur_1->nom);
  fichier_1 = fopen(coureur_1->nom, "r");

  if (fichier_1 == NULL) {
    fichier_1 = fopen(coureur_1->nom, "w");
  }
  else {
    fichier_1 = fopen(coureur_1->nom, "a");
  }
  
  if (fichier_1 == NULL) {
    fprintf(stderr, "\nErreur lors de l'ouverture du fichier.\n");
    exit(EXIT_FAILURE);
  }

  fprintf(fichier_1, "\n------------------ ÉPREUVE DU RELAIS 4x400m ----------------------\n\n");

  fprintf(fichier_1, "Date de l'épreuve : %02d/%02d/%d\n", epreuve->jour, epreuve->mois, epreuve->annee);
  fprintf(fichier_1, "Lieu de l'épreuve : %s\n", epreuve->lieu);
  fprintf(fichier_1, "Temps personnel réalisé : %02dmin %02ds\n", coureur_1->minutes, coureur_1->secondes);
  fprintf(fichier_1, "Temps d'équipe réalisé : %02dmin %02ds\n", minutes, secondes);
  fprintf(fichier_1, "Position : n°1\n");

  fclose(fichier_1);
  char *point_1 = strrchr(coureur_1->nom, '.');

  if (point_1 != NULL) {
      *point_1 = '\0';
  }

  sprintf(coureur_2->nom, "%s.txt", coureur_2->nom);
  fichier_2 = fopen(coureur_2->nom, "r");
  
  if (fichier_2 == NULL) {
    fichier_2 = fopen(coureur_2->nom, "w");
  }
  else {
    fichier_2 = fopen(coureur_2->nom, "a");
  }
  
  if (fichier_2 == NULL) {
    fprintf(stderr, "\nErreur lors de l'ouverture du fichier.\n");
    exit(EXIT_FAILURE);
  }

  fprintf(fichier_2, "\n------------------ ÉPREUVE DU RELAIS 4x400m ----------------------\n\n");

  fprintf(fichier_2, "Date de l'épreuve : %02d/%02d/%d\n", epreuve->jour, epreuve->mois, epreuve->annee);
  fprintf(fichier_2, "Lieu de l'épreuve : %s\n", epreuve->lieu);
  fprintf(fichier_2, "Temps personnel réalisé : %02dmin %02ds\n", coureur_2->minutes, coureur_2->secondes);
  fprintf(fichier_2, "Temps d'équipe réalisé : %02dmin %02ds\n", minutes, secondes);
  fprintf(fichier_2, "Position : n°2\n");

  fclose(fichier_2);
  char *point_2 = strrchr(coureur_2->nom, '.');

  if (point_2 != NULL) {
      *point_2 = '\0';
  }

  sprintf(coureur_3->nom, "%s.txt", coureur_3->nom);
  fichier_3 = fopen(coureur_3->nom, "r");

  if (fichier_3 == NULL) {
    fichier_3 = fopen(coureur_3->nom, "w");
  }
  else {
    fichier_3 = fopen(coureur_3->nom, "a");
  }
  
  if (fichier_3 == NULL) {
    fprintf(stderr, "\nErreur lors de l'ouverture du fichier.\n");
    exit(EXIT_FAILURE);
  }

  fprintf(fichier_3, "\n------------------ ÉPREUVE DU RELAIS 4x400m ----------------------\n\n");

  fprintf(fichier_3, "Date de l'épreuve : %02d/%02d/%d\n", epreuve->jour, epreuve->mois, epreuve->annee);
  fprintf(fichier_3, "Lieu de l'épreuve : %s\n", epreuve->lieu);
  fprintf(fichier_3, "Temps personnel réalisé : %02dmin %02ds\n", coureur_3->minutes, coureur_3->secondes);
  fprintf(fichier_3, "Temps d'équipe réalisé : %02dmin %02ds\n", minutes, secondes);
  fprintf(fichier_3, "Position : n°3\n");

  fclose(fichier_3);
  char *point_3 = strrchr(coureur_3->nom, '.');

  if (point_3 != NULL) {
      *point_3 = '\0';
  }

  sprintf(coureur_4->nom, "%s.txt", coureur_4->nom);
  fichier_4 = fopen(coureur_4->nom, "r");

  if (fichier_4 == NULL) {
    fichier_4 = fopen(coureur_4->nom, "w");
  }
  else {
    fichier_4 = fopen(coureur_4->nom, "a");
  }
  
  if (fichier_4 == NULL) {
    fprintf(stderr, "\nErreur lors de l'ouverture du fichier.\n");
    exit(EXIT_FAILURE);
  }

  fprintf(fichier_4, "\n------------------ ÉPREUVE DU RELAIS 4x400m ----------------------\n\n");

  fprintf(fichier_4, "Date de l'épreuve : %02d/%02d/%d\n", epreuve->jour, epreuve->mois, epreuve->annee);
  fprintf(fichier_4, "Lieu de l'épreuve : %s\n", epreuve->lieu);
  fprintf(fichier_4, "Temps personnel réalisé : %02dmin %02ds\n", coureur_4->minutes, coureur_4->secondes);
  fprintf(fichier_4, "Temps d'équipe réalisé : %02dmin %02ds\n", minutes, secondes);
  fprintf(fichier_4, "Position : n°4\n");

  fclose(fichier_4);
  char *point_4 = strrchr(coureur_4->nom, '.');

  if (point_4 != NULL) {
      *point_4 = '\0';
  }
}

void afficher_relais(COUREUR *coureur) {
  int i = 0, minutes, secondes, temps_min, temps_max, temps_moyen, resultat;

  printf("\n\nToutes les performances du relais : \n\n");

  for (int i = 0; i < MAX_TAILLE; i++) {
    if (coureur->temps_relais_personnel[i][0] == 0) {
      break;
    }
    coureur->minutes = coureur->temps_relais_personnel[i][0] / 60;
    coureur->secondes = coureur->temps_relais_personnel[i][0] % 60;
    printf("[%02dmin %02ds]\t", coureur->minutes, coureur->secondes);
  }

  temps_min = min_bis(coureur->temps_relais_personnel);
  coureur->min_relais = temps_min;
  minutes = temps_min / 60;
  secondes = temps_min % 60;
  printf("\n\nMeilleure performance du relais : %02dmin %02ds\n", minutes, secondes);

  temps_max = max_bis(coureur->temps_relais_personnel);
  coureur->max_relais = temps_max;
  minutes = temps_max / 60;
  secondes = temps_max % 60;
  printf("\nPire performance du relais : %02dmin %02ds\n", minutes, secondes);

  temps_moyen = moyenne_bis(coureur->temps_relais_personnel);
  coureur->moyenne_relais = temps_moyen;
  minutes = temps_moyen / 60;
  secondes = temps_moyen % 60;
  printf("\nMoyenne des performances du relais : %02dmin %02ds\n", minutes, secondes);

  while (i < MAX_TAILLE && coureur->temps_relais_personnel[i][0] != 0) {
    if (i > 0){
      resultat = coureur->temps_relais_personnel[i-1] - coureur->temps_relais_personnel[i];
      minutes = resultat / 60;
      secondes = resultat % 60;

      if (resultat > 0 && resultat > 59) {
        printf("\nAmélioration de %02dmin %02ds entre la %de et la %de performance du relais.\n", minutes, secondes, i, i+1);
      } else if (resultat > 0 && resultat < 59) {
        printf("\nAmélioration de %02ds entre la %de et la %de performance du relais.\n", secondes, i, i+1);
      } else if (resultat < 0 && resultat < -59) {
        printf("\nBaisse de %02dmin %02ds secondes entre la %de et la %de performance du relais.\n", -minutes, -secondes, i, i+1);
      } else if (resultat < 0 && resultat > -59) {
        printf("\nBaisse de %02ds secondes entre la %de et la %de performance du relais.\n", -secondes, i, i+1);
      } else {
        printf("\nTemps constant entre la %de et la %de performance du relais.\n", i, i+1);
      }
    }
    i++;
  }
}

/// FONCTION DE TRI (PAR SÉLECTION) ///

void tri_relais(EPREUVE *epreuve) {
    for (int i = 0; i < MAX_TAILLE - 1; i++) {
        if (epreuve->tab_coureurs[i] == NULL) {
            break; // Sortir de la boucle si nous avons atteint la fin des coureurs valides
        }
        int min_idx = i;

        // Trouver l'élément minimum dans le tableau non trié
        for (int j = i + 1; j < MAX_TAILLE; j++) {
            if (epreuve->tab_coureurs[j] == NULL) {
                break; // Sortir de la boucle si nous avons atteint la fin des coureurs valides
            }
            if (epreuve->tab_coureurs[j]->moyenne_relais < epreuve->tab_coureurs[min_idx]->moyenne_relais) {
                min_idx = j;
            }
        }

        // Échanger l'élément minimum avec le premier élément
        COUREUR *temp = epreuve->tab_coureurs[min_idx];
        epreuve->tab_coureurs[min_idx] = epreuve->tab_coureurs[i];
        epreuve->tab_coureurs[i] = temp;
    }
}

void moyenne_relais(EPREUVE *epreuve) {
    int i = 0;

    while (i < MAX_TAILLE && epreuve->tab_coureurs[i] != NULL) {
        int j = 0, temps_moyen = 0, nb_temps = 0;

        // Parcourir tous les temps du relais pour le coureur actuel
        while (j < MAX_TAILLE && epreuve->tab_coureurs[i]->temps_relais_equipe[j][0] != 0) {
            temps_moyen += epreuve->tab_coureurs[i]->temps_relais_equipe[j][0];
            j++;
            nb_temps++;
        }

        // Calculer la moyenne seulement si nb_temps est supérieur à 0 pour éviter la division par zéro
        if (nb_temps > 0) {
            epreuve->tab_coureurs[i]->moyenne_relais = temps_moyen / nb_temps;
        } else {
            epreuve->tab_coureurs[i]->moyenne_relais = 0; // Aucun temps enregistré
        }
        i++;
    }
}