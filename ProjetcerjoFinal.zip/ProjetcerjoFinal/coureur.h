#ifndef COUREUR_H
#define COUREUR_H

#include <stdio.h>
#include <stdlib.h> // Pour malloc

#define MAX_TAILLE 300
#define MAX_CHAR 50

/// STRUCTURES DE BASE ///

typedef struct COUREUR {
    FILE *fichier;
    char nom[MAX_CHAR];
    char prenom[MAX_CHAR];
    int age;
    float temps_100m[MAX_TAILLE];
    float max_100m;
    float min_100m;
    float moyenne_100m;
    int temps_400m[MAX_TAILLE][MAX_TAILLE];
    int max_400m;
    int min_400m;
    int moyenne_400m;
    int temps_5000m[MAX_TAILLE][MAX_TAILLE];
    int heures;
    int minutes;
    int secondes;
    int max_5000m;
    int min_5000m;
    int moyenne_5000m;
    int temps_relais_equipe[MAX_TAILLE][MAX_TAILLE];
    int temps_relais_personnel[MAX_TAILLE][MAX_TAILLE];
    int max_relais;
    int min_relais;
    int moyenne_relais;
    int temps_marathon[MAX_TAILLE][MAX_TAILLE];
    int max_marathon;
    int min_marathon;
    int moyenne_marathon;
} COUREUR;

// Déclaration de la fonction constructeur_coureur
COUREUR *constructeur_coureur();

// Déclaration des fonctions
int char_valide(const char *chaine);
int scan_Int(char *message);
float scan_Float(char *message);

#endif // COUREUR_H