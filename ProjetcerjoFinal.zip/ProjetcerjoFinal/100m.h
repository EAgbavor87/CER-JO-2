#ifndef CENT_H
#define CENT_H

#include "coureur.h"
#include "epreuve.h"

void ajouter_100m(COUREUR *coureur, EPREUVE *epreuve);
void afficher_100m(COUREUR *coureur);
void tri_100m(EPREUVE *epreuve);
void moyenne_100m(EPREUVE *epreuve);

#endif