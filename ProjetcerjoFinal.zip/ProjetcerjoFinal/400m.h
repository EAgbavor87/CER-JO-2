#ifndef QUATRE_CENT_H
#define QUATRE_CENT_H

#include "coureur.h"
#include "epreuve.h"

void ajouter_400m(COUREUR *coureur, EPREUVE *epreuve);
void afficher_400m(COUREUR *coureur);
void tri_400m(EPREUVE *epreuve);
void moyenne_400m(EPREUVE *epreuve);

#endif