#ifndef __MAIN__H
#define __MAIN__H

#include "coureur.h"
#include "epreuve.h"

void menu(COUREUR *coureur, EPREUVE *epreuve);

#endif