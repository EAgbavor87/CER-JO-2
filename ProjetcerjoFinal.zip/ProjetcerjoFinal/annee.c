#include <time.h>
#include "annee.h"

/// FONCTION POUR DETERMINER L'ACTUELLE ///

int annee_actuelle() {
  time_t temps_actuel;
  struct tm *temps_info;

  // Obtenir le temps actuel
  time(&temps_actuel);

  // Convertir le temps actuel en temps local
  temps_info = localtime(&temps_actuel);

  // Extraire et retourner l'année
  return temps_info->tm_year + 1900; // tm_year donne l'année depuis 1900
}