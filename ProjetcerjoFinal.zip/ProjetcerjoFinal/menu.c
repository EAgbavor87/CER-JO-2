#include <string.h>
#include "coureur.h"
#include "epreuve.h"
#include "100m.h"
#include "400m.h"
#include "5000m.h"
#include "marathon.h"
#include "relais.h"
#include "statistiques.h"
#include "fichier.h"
#include "menu.h"

void menu(COUREUR *coureur, EPREUVE *epreuve) {
  int choix;
  
  printf("\n\n------------------ MENU PRINCIPAL ----------------------\n");
  printf("\nCoureur actuel : %s %s\n", coureur->prenom, coureur->nom);

  do {
    choix = scan_Int(
        "\n[1] Fermer le programme\n[2] Remplir les performances de l'athlète\n[3] Ajouter un "
        "nouvel athlète\n[4] Afficher les performances de l'athlète\n[5] Visualiser vos meilleurs coureurs\n[6] Supprimer le fichier de l'athlète"
        "\n[7] Voir tous vos coureurs\n[8] Consulter l'historique d'un coureur\n\nSaisir votre choix : ");

        if (choix < 1 || choix > 8) {
          printf("\nERREUR : Le numéro doit être compris entre 1 et 8 inclus.\n");
        }
  } while (choix < 1 || choix > 8);

  if (choix == 1) {
    printf("\nAu revoir et à bientôt !\n");
    free(coureur);
    free(epreuve);
    exit(EXIT_SUCCESS);
  } else if (choix == 2) {
    if (strcmp(coureur->nom, "") == 0) {
      printf("\nERREUR : Vous n'avez pas encore ajouté de coureur actuel.");
      menu(coureur, epreuve);
      return;
    }
    ajouter_entrainement(coureur, epreuve);
  } else if (choix == 3) {
    coureur = constructeur_coureur();
    ajouter_entrainement(coureur, epreuve);
  } else if (choix == 4) {
    if (strcmp(coureur->nom, "") == 0) {
      printf("\nERREUR : Vous n'avez pas encore ajouté de coureur actuel.");
      menu(coureur, epreuve);
      return;
    }

    do {
      choix = scan_Int(
          "\n[1] Fermer le programme\n[2] Afficher ses performances du 100m\n[3] Afficher ses "
          "performances du 400\n[4] Afficher ses performances du 5000m\n[5] "
          "Afficher ses performances du Relais\n[6] Afficher ses performances "
          "du marathon\n[7] Afficher toutes les performances\n\nSaisir votre choix : ");

          if (choix < 1 || choix > 8) {
          printf("\nERREUR : Le numéro doit être compris entre 1 et 8 inclus.\n");
        }
    } while (choix < 1 || choix > 8);

    if (choix == 1) {
      printf("\nAu revoir et à bientôt !\n");
      free(coureur);
      free(epreuve);
      exit(EXIT_SUCCESS);
    } else if (choix == 2) {
      afficher_100m(coureur);
    } else if (choix == 3) {
      afficher_400m(coureur);
    } else if (choix == 4) {
      afficher_5000m(coureur);
    } else if (choix == 5) {
      afficher_relais(coureur);
    } else if (choix == 6) {
      afficher_marathon(coureur);
    } else if (choix == 7) {
      afficher_100m(coureur);
      afficher_400m(coureur);
      afficher_5000m(coureur);
      afficher_relais(coureur);
      afficher_marathon(coureur);
    } 
  } else if (choix == 5) {
      meilleurs_coureurs(epreuve);
  } else if (choix == 6) {
      supprimer_fichier(coureur->nom);
    } else if (choix == 7) {
      afficher_liste_coureurs();
    } else if (choix == 8) {
      rechercher_coureur();
    }

  menu(coureur, epreuve);
}