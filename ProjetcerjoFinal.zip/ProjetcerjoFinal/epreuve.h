#ifndef EPREUVE_H
#define EPREUVE_H

#include "coureur.h"

typedef struct EPREUVE {
  COUREUR *tab_coureurs[MAX_TAILLE];
  char nom[MAX_CHAR];
  int jour;
  int mois;
  int annee;
  int dates_relais[MAX_TAILLE];
  char lieu[MAX_CHAR];
} EPREUVE;

void ajouter_entrainement(COUREUR *coureur, EPREUVE *epreuve);
void tri_relais(EPREUVE *epreuve);

#endif // EPREUVE_H