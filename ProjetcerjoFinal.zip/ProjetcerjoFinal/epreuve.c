#include "coureur.h"
#include "epreuve.h"
#include "100m.h"
#include "400m.h"
#include "5000m.h"
#include "relais.h"
#include "marathon.h"

void ajouter_entrainement(COUREUR *coureur, EPREUVE *epreuve) {
  int num_epreuve;

  printf("\n------------------ ENTRAINEMENT ----------------------\n");

  do {
    num_epreuve = scan_Int(
        "\nÀ quelle épreuve ce coureur a participé durant cet entrainement "
        "?\n\n[1] Quitter\n[2] Épreuve du 100m\n[3] Épreuve du 400m\n[4] Épreuve du 5000m\n[5] Épreuve du relais\n[6] Épreuve du marathon\n\n"
        "Saisissez le numéro correspondant à l'épreuve : ");

        if (num_epreuve < 1 || num_epreuve > 6) {
          printf("\nERREUR : Le numéro de l'épreuve doit être compris entre 1 et 6 inclus.\n");
        }
  } while (num_epreuve < 1 || num_epreuve > 6);

  if (num_epreuve == 1) {
    printf("\nAu revoir et à bientôt !\n");
    free(coureur);
    free(epreuve);
    exit(EXIT_SUCCESS);
  } else if (num_epreuve == 2) {
    ajouter_100m(coureur, epreuve);
  } else if (num_epreuve == 3) {
    ajouter_400m(coureur, epreuve);
  } else if (num_epreuve == 4) {
    ajouter_5000m(coureur, epreuve);
  } else if (num_epreuve == 5) {
    COUREUR *coureur_1 = coureur;
    printf("\n----- Second coureur -----\n\n");
    COUREUR *coureur_2 = constructeur_coureur();
    printf("\n----- Troisième coureur -----\n\n");
    COUREUR *coureur_3 = constructeur_coureur();
    printf("\n----- Quatrième coureur -----\n\n");
    COUREUR *coureur_4 = constructeur_coureur();
    ajouter_relais(coureur_1, coureur_2, coureur_3, coureur_4, epreuve);
  } else if (num_epreuve == 6) {
    ajouter_marathon(coureur, epreuve);
  } 
}