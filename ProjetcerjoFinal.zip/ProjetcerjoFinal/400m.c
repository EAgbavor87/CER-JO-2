#include <string.h>
#include "coureur.h"
#include "epreuve.h"
#include "annee.h"
#include "statistiques.h"
#include "400m.h"

void ajouter_400m(COUREUR *coureur, EPREUVE *epreuve) {
  FILE *fichier = coureur->fichier;
  int i = 0, j = 0;

  printf("\n------------------ ÉPREUVE DU 400m "
         "----------------------\n\nSaisir la date\n\n");

  do {
    epreuve->jour = scan_Int("Jour : "); 

    if (epreuve->jour < 1 || epreuve->jour > 30) {
      printf("\nERREUR : Le jour doit être compris entre 1 et 30 inclus.\n");
    }
  } while (epreuve->jour < 1 || epreuve->jour > 30);

  do {
    epreuve->mois = scan_Int("Mois : ");

    if (epreuve->mois < 1 || epreuve->mois > 12) {
      printf("\nERREUR : Le mois doit être compris entre 1 et 12 inclus.\n");
    }
  } while (epreuve->mois < 1 || epreuve->mois > 12);

  do {
    epreuve->annee = scan_Int("Année : ");

    if (epreuve->annee != annee_actuelle()) {
      printf("\nERREUR : L'année doit correspondre à celle actuelle.\n");
    }
  } while (epreuve->annee != annee_actuelle());

  do {
    printf("\nOù le coureur a réalisé l'entrainement ? : ");
    fgets(epreuve->lieu, MAX_CHAR, stdin);
    // Supprimer le caractère de nouvelle ligne '\n' ajouté par fgets
    epreuve->lieu[strcspn(epreuve->lieu, "\n")] = '\0';

    if (strlen(epreuve->lieu) < 2 || strlen(epreuve->lieu) > MAX_CHAR) {
      printf("\nERREUR : Le lieu doit contenir au moins 2 lettres et %d au maximum.\n", MAX_CHAR);
    }
  } while (strlen(epreuve->lieu) < 2 || strlen(epreuve->lieu) > MAX_CHAR || !char_valide(epreuve->lieu));

  do {
    printf("\nQuel est le temps réalisé ?");
    coureur->minutes = scan_Int("\nMinutes : ");
    coureur->secondes = scan_Int("Secondes : ");

    if (coureur->minutes > 60 || coureur->secondes > 60) {
      printf("\nERREUR : Les minutes et secondes sont comprises entre 1 et 59.\n");
    }
  } while (coureur->minutes > 60 || coureur->secondes > 60);

  while (i < MAX_TAILLE && coureur->temps_400m[i][0] != 0) {
    i++;
  }

  while (j < MAX_TAILLE) {
    if (coureur->nom == epreuve->tab_coureurs[j]->nom && coureur->prenom == epreuve->tab_coureurs[j]->prenom && coureur->age == epreuve->tab_coureurs[j]->age) {
      break;
    } else if (epreuve->tab_coureurs[j] == NULL) {
      epreuve->tab_coureurs[j] = coureur;
      break;
    }
    j++;
  }

  coureur->temps_400m[i][0] = (coureur->minutes * 60) + coureur->secondes;
  strcpy(epreuve->nom, "400m");

  // Construire le nom du fichier en utilisant le contenu de la variable
  sprintf(coureur->nom, "%s.txt", coureur->nom);

  // Vérifier si le fichier existe
  fichier = fopen(coureur->nom, "r");
  if (fichier == NULL) {
    fichier = fopen(coureur->nom, "w");
  }
  else {
    fichier = fopen(coureur->nom, "a");
  }
  
  if (fichier == NULL) {
    fprintf(stderr, "\nErreur lors de l'ouverture du fichier.\n");
    exit(EXIT_FAILURE);
  }

  fprintf(fichier, "\n------------------ ÉPREUVE DU 400m ----------------------\n\n");

  fprintf(fichier, "Date de l'épreuve : %02d/%02d/%d\n", epreuve->jour, epreuve->mois, epreuve->annee);
  fprintf(fichier, "Lieu de l'épreuve : %s\n", epreuve->lieu);
  fprintf(fichier, "Temps réalisé : %02dmin %02ds\n", coureur->minutes, coureur->secondes);

  fclose(fichier);

  char *point = strrchr(coureur->nom, '.');

  if (point != NULL) {
      *point = '\0';
  }
}

void afficher_400m(COUREUR *coureur) {
  int i = 0, minutes, secondes, temps_min, temps_max, temps_moyen, resultat; 

  printf("\n\nToutes les performances du 400m : \n\n");

  for (int i = 0; i < MAX_TAILLE; i++) {
    if (coureur->temps_400m[i][0] == 0) {
      break;
    }
    minutes = coureur->temps_400m[i][0] / 60;
    secondes = coureur->temps_400m[i][0] % 60;
    printf("[%02dmin %02ds]\t", minutes, secondes);
  }

  temps_min = min_bis(coureur->temps_400m);
  coureur->min_400m = temps_min;
  minutes = temps_min / 60;
  secondes = temps_min % 60;
  printf("\n\nMeilleure performance du 400m : %02dmin %02ds\n", minutes, secondes);

  temps_max = max_bis(coureur->temps_400m);
  coureur->max_400m = temps_max;
  minutes = temps_max / 60;
  secondes = temps_max % 60;
  printf("\nPire performance du 400m : %02dmin %ds\n", minutes, secondes);

  temps_moyen = moyenne_bis(coureur->temps_400m);
  coureur->moyenne_400m = temps_moyen;
  minutes = temps_moyen / 60;
  secondes = temps_moyen % 60;
  printf("\nMoyenne des performances du 400m : %02dmin %02ds\n", minutes, secondes);

  while (i < MAX_TAILLE && coureur->temps_400m[i][0] != 0) {
    if (i > 0){
      resultat = coureur->temps_400m[i-1] - coureur->temps_400m[i];
      minutes = resultat / 60;
      secondes = resultat % 60;

      if (resultat > 0 && resultat > 59) {
        printf("\nAmélioration de %02dmin %02ds entre la %de et la %de performance du 400m.\n", minutes, secondes, i, i+1);
      } else if (resultat > 0 && resultat < 59) {
        printf("\nAmélioration de %02ds entre la %de et la %de performance du 400m.\n", secondes, i, i+1);
      } else if (resultat < 0 && resultat > -59) {
        printf("\nBaisse de %02dmin %ds entre la %de et la %de performance du 400m.\n", -minutes, -secondes, i, i+1);
      } else if (resultat < 0 && resultat < -59) {
        printf("\nBaisse de %02ds entre la %de et la %de performance du 400m.\n", -secondes, i, i+1);
      } else {
        printf("\nTemps constant entre la %de et la %de performance du 400m.\n", i, i+1);
      }
    }
    i++;
  }
}

/// FONCTION DE TRI (PAR SÉLECTION) ///

void tri_400m(EPREUVE *epreuve) {
    for (int i = 0; i < MAX_TAILLE - 1; i++) {
        if (epreuve->tab_coureurs[i] == NULL) {
            break; // Sortir de la boucle si nous avons atteint la fin des coureurs valides
        }
        int min_idx = i;
        
        // Trouver l'élément minimum dans le tableau non trié
        for (int j = i + 1; j < MAX_TAILLE; j++) {
            if (epreuve->tab_coureurs[j] == NULL) {
                break; // Sortir de la boucle si nous avons atteint la fin des coureurs valides
            }
            if (epreuve->tab_coureurs[j]->moyenne_400m < epreuve->tab_coureurs[min_idx]->moyenne_400m) {
                min_idx = j;
            }
        }
        
        // Échanger l'élément minimum avec le premier élément
        COUREUR *temp = epreuve->tab_coureurs[min_idx];
        epreuve->tab_coureurs[min_idx] = epreuve->tab_coureurs[i];
        epreuve->tab_coureurs[i] = temp;
    }
}

void moyenne_400m(EPREUVE *epreuve) {
    int i = 0;

    while (i < MAX_TAILLE && epreuve->tab_coureurs[i] != NULL) {
        int j = 0, temps_moyen = 0, nb_temps = 0;

        // Parcourir tous les temps de 400m pour le coureur actuel
        while (j < MAX_TAILLE && epreuve->tab_coureurs[i]->temps_400m[j][0] != 0) {
            temps_moyen += epreuve->tab_coureurs[i]->temps_400m[j][0];
            j++;
            nb_temps++;
        }

        // Calculer la moyenne seulement si nb_temps est supérieur à 0 pour éviter la division par zéro
        if (nb_temps > 0) {
            epreuve->tab_coureurs[i]->moyenne_400m = temps_moyen / nb_temps;
        } else {
            epreuve->tab_coureurs[i]->moyenne_400m = 0; // Aucun temps enregistré
        }
        i++;
    }
}