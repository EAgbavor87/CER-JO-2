#include "coureur.h"
#include "epreuve.h"
#include "100m.h"
#include "400m.h"
#include "5000m.h"
#include "marathon.h"
#include "relais.h"
#include "statistiques.h"

/// FONCTION QUI REVOIE LE MAXIMUM D'UN TABLEAU DE FLOAT ///
float max(float tab[]) {
    float valeur_max = tab[0];
    int i = 0;

    while (tab[i] != 0.0) {
        if (tab[i] > valeur_max) {
            valeur_max = tab[i];
        }
        i++;
    }

    return valeur_max;
}

/// FONCTION QUI REVOIE LE MINIMUM D'UN TABLEAU DE FLOAT ///
float min(float tab[]) {
    float valeur_min = tab[0];
    int i = 0;

    while (tab[i] != 0.0) {
        if (tab[i] < valeur_min) {
            valeur_min = tab[i];
        }
        i++;
    }

    return valeur_min;
}

/// FONCTION QUI REVOIE LA MOYENNE D'UN TABLEAU DE FLOAT ///
float moyenne(float tab[]) {
    float temps_moyen = 0.0;
    int i = 0;

    while (tab[i] != 0.0) {
        temps_moyen += tab[i];
        i++;
    }

    if (i == 0) {
        return 0.0;
    }

    return temps_moyen / i;
}

/// FONCTION QUI REVOIE LE MAXIMUM D'UN TABLEAU 2D D'ENTIERS ///
int max_bis(int tab[MAX_TAILLE][MAX_TAILLE]) {
    int i = 0, valeur_max = tab[0][0];

    while (tab[i][0] != 0) {
        if (tab[i][0] > valeur_max) {
            valeur_max = tab[i][0];
        }
        i++;
    }

    return valeur_max;
}

/// FONCTION QUI REVOIE LE MINIMUM D'UN TABLEAU 2D D'ENTIERS ///
int min_bis(int tab[MAX_TAILLE][MAX_TAILLE]) {
    int i = 0, valeur_min = tab[0][0];

    while (tab[i][0] != 0) {
        if (tab[i][0] < valeur_min) {
            valeur_min = tab[i][0];
        }
        i++;
    }

    return valeur_min;
}

/// FONCTION QUI REVOIE LA MOYENNE D'UN TABLEAU 2D D'ENTIERS ///
int moyenne_bis(int tab[MAX_TAILLE][MAX_TAILLE]) {
    int i = 0, temps_moyen = 0;

    while (tab[i][0] != 0) {
        temps_moyen += tab[i][0];
        i++;
    }

    if (i == 0) {
        return 0;
    }

    return temps_moyen / i;
}

void meilleurs_coureurs(EPREUVE *epreuve) {
  int choix, temps, heure, minutes, secondes, i = 0;

  while (i < MAX_TAILLE && epreuve->tab_coureurs[i] != NULL) {
    i++;
  }

  if (i < 3) {
    printf("\nERREUR : Vous devez entrer au moins 3 coureurs.");
    return;
  }

  do
  {
    choix = scan_Int("\n[1] Meilleurs coureurs du 100m\n[2] Meilleurs coureurs du 400m\n[3] Meilleurs coureurs du 5000m\n[4] Meilleurs coureurs du marathon\n[5] Meilleurs coureurs du relais\n\nSaisir votre choix : ");

    if (choix < 1 || choix > 5) {
      printf("\nERREUR : Votre choix doit être uniquement compris entre 1 et 5 inclu.");
    }
  } while (choix < 1 || choix > 5);

  printf("\nVoici les coureurs sélectionnés pour les JO : ");
  
  if (choix == 1) {
    moyenne_100m(epreuve);
    tri_100m(epreuve);
    printf("\n\n%s %s (Temps moyen 100m : %.2f secondes)", epreuve->tab_coureurs[0]->prenom, epreuve->tab_coureurs[0]->nom, epreuve->tab_coureurs[0]->moyenne_100m);
    printf("\n%s %s (Temps moyen 100m : %.2f secondes)", epreuve->tab_coureurs[1]->prenom, epreuve->tab_coureurs[1]->nom, epreuve->tab_coureurs[1]->moyenne_100m);
    printf("\n%s %s (Temps moyen 100m : %.2f secondes)", epreuve->tab_coureurs[2]->prenom, epreuve->tab_coureurs[2]->nom, epreuve->tab_coureurs[2]->moyenne_100m);
  } 
  
  else if (choix == 2) {
    moyenne_400m(epreuve);
    tri_400m(epreuve);
    minutes = epreuve->tab_coureurs[0]->moyenne_400m / 60;
    secondes = epreuve->tab_coureurs[0]->moyenne_400m % 60;
    printf("\n%s %s (Temps moyen 400m : %02dmin %02ds)", epreuve->tab_coureurs[0]->prenom, epreuve->tab_coureurs[0]->nom, minutes, secondes);
    minutes = epreuve->tab_coureurs[1]->moyenne_400m / 60;
    secondes = epreuve->tab_coureurs[1]->moyenne_400m % 60;
    printf("\n%s %s (Temps moyen 400m : %02dmin %02ds)", epreuve->tab_coureurs[1]->prenom, epreuve->tab_coureurs[1]->nom, minutes, secondes);
    minutes = epreuve->tab_coureurs[2]->moyenne_400m / 60;
    secondes = epreuve->tab_coureurs[2]->moyenne_400m % 60;
    printf("\n%s %s (Temps moyen 400m : %02dmin %02ds)", epreuve->tab_coureurs[2]->prenom, epreuve->tab_coureurs[2]->nom, minutes, secondes);
  }

  else if (choix == 3) {
    moyenne_5000m(epreuve);
    tri_5000m(epreuve);
    minutes = epreuve->tab_coureurs[0]->moyenne_5000m / 60;
    secondes = epreuve->tab_coureurs[0]->moyenne_5000m % 60;
    printf("\n\n%s %s (Temps moyen 5000m : %02dmin %02ds)", epreuve->tab_coureurs[0]->prenom, epreuve->tab_coureurs[0]->nom, minutes, secondes);
    minutes = epreuve->tab_coureurs[1]->moyenne_5000m / 60;
    secondes = epreuve->tab_coureurs[1]->moyenne_5000m % 60;
    printf("\n%s %s (Temps moyen 5000m : %02dmin %02ds)", epreuve->tab_coureurs[1]->prenom, epreuve->tab_coureurs[1]->nom, minutes, secondes);
    minutes = epreuve->tab_coureurs[2]->moyenne_5000m / 60;
    secondes = epreuve->tab_coureurs[2]->moyenne_5000m % 60;
    printf("\n%s %s (Temps moyen 5000m : %02dmin %02ds)", epreuve->tab_coureurs[2]->prenom, epreuve->tab_coureurs[2]->nom, minutes, secondes);
  }

  else if (choix == 4) {
    moyenne_marathon(epreuve);
    tri_marathon(epreuve);
    temps = epreuve->tab_coureurs[0]->moyenne_marathon;
    heure = temps / 3600;
    temps = temps % 3600;
    minutes = temps / 60;
    secondes = temps % 60;
    printf("\n\n%s %s (Temps moyen marathon: %02dh %02dmin %02ds)", epreuve->tab_coureurs[0]->prenom, epreuve->tab_coureurs[0]->nom, heure, minutes, secondes);
    temps = epreuve->tab_coureurs[1]->moyenne_marathon;
    heure = temps / 3600;
    temps = temps % 3600;
    minutes = temps / 60;
    secondes = temps % 60;
    printf("\n%s %s (Temps moyen marathon: %02dh %02dmin %02ds)", epreuve->tab_coureurs[1]->prenom, epreuve->tab_coureurs[1]->nom, heure, minutes, secondes);
    temps = epreuve->tab_coureurs[2]->moyenne_marathon;
    heure = temps / 3600;
    temps = temps % 3600;
    minutes = temps / 60;
    secondes = temps % 60;
    printf("\n%s %s (Temps moyen marathon : %02dh %02dmin %02ds)", epreuve->tab_coureurs[2]->prenom, epreuve->tab_coureurs[2]->nom, heure, minutes, secondes);
  }

  else if (choix == 5) {
    moyenne_relais(epreuve);
    tri_relais(epreuve);
    minutes = epreuve->tab_coureurs[0]->moyenne_relais / 60;
    secondes = epreuve->tab_coureurs[0]->moyenne_relais % 60;
    printf("\n\n%s %s (Temps moyen relais: %02dmin %02ds)", epreuve->tab_coureurs[0]->prenom, epreuve->tab_coureurs[0]->nom, minutes, secondes);
    minutes = epreuve->tab_coureurs[1]->moyenne_relais / 60;
    secondes = epreuve->tab_coureurs[1]->moyenne_relais % 60;
    printf("\n%s %s (Temps moyen relais: %02dmin %02ds)", epreuve->tab_coureurs[1]->prenom, epreuve->tab_coureurs[1]->nom, minutes, secondes);
    minutes = epreuve->tab_coureurs[2]->moyenne_relais / 60;
    secondes = epreuve->tab_coureurs[2]->moyenne_relais % 60;
    printf("\n%s %s (Temps moyen relais: %02dmin %02ds)", epreuve->tab_coureurs[2]->prenom, epreuve->tab_coureurs[2]->nom, minutes, secondes);
  }
}