#ifndef FICHIER_H
#define FICHIER_H

#include "coureur.h"

int afficher_liste_coureurs();
void liste_coureur(COUREUR *coureur);
void rechercher_coureur();

/// FONCTION POUR SUPPRIMER UN FICHIER ///

int supprimer_fichier(char *nom_fichier);

#endif