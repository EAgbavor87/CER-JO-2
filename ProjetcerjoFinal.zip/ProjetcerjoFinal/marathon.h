#ifndef MARATHON_H
#define MARATHON_H

#include "coureur.h"
#include "epreuve.h"

void ajouter_marathon(COUREUR *coureur, EPREUVE *epreuve);
void afficher_marathon(COUREUR *coureur);
void tri_marathon(EPREUVE *epreuve);
void moyenne_marathon(EPREUVE *epreuve);

#endif