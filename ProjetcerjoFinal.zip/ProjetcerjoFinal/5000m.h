#ifndef CINQ_MILLE_H
#define CINQ_MILLE_H

#include "coureur.h"
#include "epreuve.h"

void ajouter_5000m(COUREUR *coureur, EPREUVE *epreuve);
void afficher_5000m(COUREUR *coureur);
void tri_5000m(EPREUVE *epreuve);
void moyenne_5000m(EPREUVE *epreuve);

#endif