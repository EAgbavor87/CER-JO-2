#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "coureur.h"
#include "fichier.h"
#include "scan.h"

int afficher_liste_coureurs() {
    FILE *fichier_coureur = fopen("liste_coureurs.txt", "r");
    if (fichier_coureur == NULL) {
        printf("Erreur lors de l'ouverture du fichier liste_coureurs.txt.\n");
        return 1;
    }

    char ligne[MAX_TAILLE];
    printf("\nVoici la liste des coureurs enregistrés : \n\n");
    while (fgets(ligne, sizeof(ligne), fichier_coureur)) {
        printf("%s", ligne);
    }

    fclose(fichier_coureur);
    return 0;
}

void liste_coureur(COUREUR *coureur) {
  // Ouvrir le fichier des coureurs en mode append pour ajouter un nouveau coureur
  FILE *fichier_Coureurs = fopen("liste_coureurs.txt", "a");
  if (fichier_Coureurs == NULL) {
      fprintf(stderr, "Erreur lors de l'ouverture du fichier liste_coureurs.txt.\n");
      exit(EXIT_FAILURE);
  }

  fprintf(fichier_Coureurs, "%s\n", coureur->nom);
  fclose(fichier_Coureurs);

  // Créer un fichier spécifique pour chaque coureur
  char nom_fichier[MAX_CHAR];
  snprintf(nom_fichier, sizeof(nom_fichier), "%s.txt", coureur->nom);

  fichier_Coureurs = fopen(nom_fichier, "a");
  if (fichier_Coureurs == NULL) {
      fprintf(stderr, "Erreur lors de l'ouverture du fichier %s.\n", nom_fichier);
      exit(EXIT_FAILURE);
  }
}

void rechercher_coureur(){
    FILE *fichier_coureurs = NULL;
    FILE *fichier_individuel = NULL;
    char nom[MAX_CHAR];

    printf("\n------------------ RECHERCHE ----------------------\n");

    do {
        printf("\nQuel est le nom du coureur à rechercher ? : ");
        fgets(nom, MAX_CHAR, stdin);
        nom[strcspn(nom, "\n")] = '\0';

        if (strlen(nom) < 2 || strlen(nom) > MAX_CHAR) {
            printf("\nERREUR : Le nom doit contenir au moins 2 lettres et %d au maximum.\n", MAX_CHAR);
        }
    } while (strlen(nom) < 2 || strlen(nom) > MAX_CHAR || !char_valide(nom));

    fichier_coureurs = fopen("liste_coureurs.txt", "r");
    if (fichier_coureurs == NULL) {
        printf("Erreur lors de l'ouverture du fichier liste_coureurs.txt.\n");
        return;
    }

    char ligne[MAX_TAILLE];

    int trouve = 0;
    while (fgets(ligne, sizeof(ligne), fichier_coureurs)) {
        if (strstr(ligne, nom) != NULL) {
            trouve = 1;
            break;
        }
    }

    fclose(fichier_coureurs);

    if (trouve) {
        char nom_fichier[MAX_CHAR];
        snprintf(nom_fichier, sizeof(nom_fichier),"%s.txt", nom);

        fichier_individuel = fopen(nom_fichier, "r");
        if (fichier_individuel == NULL) {
            printf("Erreur lors de l'ouverture du fichier %s.\n", nom_fichier);
            return;
        }

        printf("\nContenu du fichier de %s :\n", nom);
        while (fgets(ligne, sizeof(ligne), fichier_individuel)) {
            printf("%s\n", ligne);
        }

        fclose(fichier_individuel);
    } else {
        printf("Coureur %s non trouvé dans la liste.\n", nom);
    }
}

/// FONCTION POUR SUPPRIMER UN FICHIER ///

int supprimer_fichier(char *nom_fichier) {
    strcat(nom_fichier, ".txt");
    if (remove(nom_fichier) == 0) {
        char *point = strrchr(nom_fichier, '.');
        if (point != NULL) {
            *point = '\0';
        }
        printf("\nLe fichier %s.txt a été supprimé avec succès.\n", nom_fichier);
        return 1; // Succès
    } else {
        char *point = strrchr(nom_fichier, '.');
        if (point != NULL) {
            *point = '\0';
        }
        printf("\nERREUR : Le fichier %s.txt est introuvable.\n", nom_fichier);
        return 0; // Échec
    }
}