#ifndef SCAN_H
#define SCAN_H

int scan_Int(char *message);
float scan_Float(char *message);
int char_valide(const char *message);

#endif 