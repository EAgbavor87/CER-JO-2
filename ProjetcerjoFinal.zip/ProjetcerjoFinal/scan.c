#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <float.h>
#include <ctype.h>
#include "scan.h"

/// FONCTIONS DE SÉCURISATION ///

int scan_Int(char *message) {
    int value;
    char buffer[256]; // buffer pour nettoyer l'entrée

    while (1) {
        printf("%s", message);
        if (fgets(buffer, sizeof(buffer), stdin) == NULL) {
            // Gestion de l'erreur de lecture
            printf("\nERREUR : Impossible de lire l'entrée.\n");
            exit(EXIT_FAILURE);
        }

        if (sscanf(buffer, "%d", &value) != 1) {
            // Si la conversion échoue, l'entrée n'est pas un entier valide
            printf("\nERREUR : Entrée invalide, veuillez saisir un entier.\n");
            continue;
        }

        // Vérifier si la valeur est dans la plage valide
        if (value <= 0 || value > INT_MAX) {
            printf("\nERREUR : Entrée invalide, veuillez saisir un entier positif valide.\n");
            continue;
        }

        // Si tout est correct, sortir de la boucle
        break;
    }

    return value;
}

float scan_Float(char *message) {
    float value;
    char buffer[256]; // buffer pour nettoyer l'entrée

    while (1) {
        printf("%s", message);
        if (fgets(buffer, sizeof(buffer), stdin) == NULL) {
            // Gestion de l'erreur de lecture
            printf("\nERREUR : Impossible de lire l'entrée.\n");
            exit(EXIT_FAILURE);
        }

        if (sscanf(buffer, "%f", &value) != 1) {
            // Si la conversion échoue, l'entrée n'est pas un flottant valide
            printf("\nERREUR : Entrée invalide, veuillez saisir un nombre valide.\n");
            continue;
        }

        // Vérifier si la valeur est dans la plage valide
        if (value <= 0 || value > FLT_MAX) {
            printf("\nERREUR : Entrée invalide, veuillez saisir un nombre valide.\n");
            continue;
        }

        // Si tout est correct, sortir de la boucle
        break;
    }

    return value;
}

int char_valide(const char *message) {
    for (int i = 0; message[i] != '\0'; i++) {
        if (!isalpha(message[i])) {
            printf("\nERREUR : Le nom ne doit contenir que des lettres alphabétiques.\n");
            return 0;
        }
    }
    return 1;
}